use lv316oms;

UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='1';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='2';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='3';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='4';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='5';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='6';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='7';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='8';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='9';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='10';
UPDATE `lv316oms`.`users` SET `IsUserActive`=1 WHERE `ID`='11';
