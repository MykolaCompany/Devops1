package com.softserveinc.edu.oms.persistence.dao.interfaces;

import com.softserveinc.edu.oms.domain.entities.OrderStatus;
import com.softserveinc.edu.oms.persistence.dao.IDao;

public interface IOrderStatusDao extends IDao<OrderStatus>{

}